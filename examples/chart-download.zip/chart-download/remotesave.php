<?php
include_once('../../config/config.inc.php');
include_once('../../config/defines.inc.php');
include_once('../../init.php');

$img = isset($_REQUEST['image']) ? $_REQUEST['image'] : '' ;
$img = "../../img/Motif/". trim($img) . ".png";
$uid = isset($_REQUEST['user']) ? $_REQUEST['user'] : '';
$title= isset($_REQUEST['title']) ? $_REQUEST['title'] : '';

	$ip = (isset($_SERVER['REMOTE_ADDR'])) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
	error_log($ip." - ".date("Y/m/d h:i:sa")." - remotesave.php downloaded chart for: ".$img." title: ".$title
			." - : id_customer=". ($uid/3).
			"\n", 3, _PDF_DOWNLOAD_LOG_FILE_);
	
	$apikey = 'a6ce1c61-c09b-4667-8b57-34163d164a1d';
	
	if (!$uid) {
		$value = "<div> Please logg in to get access to the chart. It is free. Just do it on the right top side of the page.</div>";
	} else {
		$value = ''._PS_URL_IMG_.'Motif/chart-download/index.php?image='.$img.'&title='.$title; // change this to your url kaleeeed.000webhostapp.com 
	}
	$result = file_get_contents("http://api.html2pdfrocket.com/pdf?apikey=" . urlencode($apikey) . "&value=" . urlencode($value));
	// Output headers so that the file is downloaded rather than displayed
	// Remember that header() must be called before any actual output is sent
	header('Content-Description: File Transfer');
	header('Content-Type: application/pdf');
	header('Expires: 0');
	header('Cache-Control: must-revalidate');
	header('Pragma: public');
	header('Content-Length: ' . strlen($result));
	 
	// Make the file a downloadable attachment - comment this out to show it directly inside the 
	// web browser.  Note that you can give the file any name you want, e.g. alias-name.pdf below:
	header('Content-Disposition: attachment; filename=' . $title.'-knitting-chart.pdf' );
	 
	// Stream PDF to user
	echo $result;

?>