<?php  
include_once('../../config/config.inc.php');
include_once('../../config/defines.inc.php');
include_once('../../init.php');

ini_set('memory_limit', '1028M');
ini_set('max_execution_time', 300); 


//Check if user is logged in
// Load PrestaShop core
error_log("Loading acces files in index.php from ". dirname(__FILE__).'/../../config/config.inc.php'); 
//include(dirname(__FILE__).'/../../config/config.inc.php');
include(dirname(__FILE__).'/../../init.php');

$context = Context::getContext();

// Check if user is logged in
if (!$context->customer->isLogged()) {
    // Not logged in → deny access
    header('HTTP/1.1 403 Forbidden');
    echo 'Access denied. Please log in.';
    exit;
}

// Otherwise, continue with your logic



// Include the main TCPDF library (search for installation path).

require_once(_PS_TOOL_DIR_.'tcpdf/config/lang/eng.php');
require_once(_PS_TOOL_DIR_.'tcpdf/tcpdf.php');

error_log("chart-download, index.php, memorry limit: ".ini_get('memory_limit')); 

class MYPDF extends TCPDF {
    
    //Page header
    public function Header() {
        // Logo
        $image_file = '../../img/KfYlogo.jpg';
        $this->Image($image_file, 10, 10, 100, '', 'JPG', '', 'T', false, 300, '', false, false, 0, false, false, false);
        // Set font
     }
    
    // Page footer
    public function Footer() {
        // Position at 15 mm from bottom
        $this->SetY(-15);
        // Set font
        $this->SetFont('helvetica', 'I', 8);
        // Page number
        $this->Cell(0, 10, 'Page '.$this->getAliasNumPage().'/'.$this->getAliasNbPages(), 0, false, 'C', 0, '', 0, false, 'T', 'M');
    }
}


$tbl = '';



// include('save.php');
// ---------------------------functions----------------------------------------------
function hex2rgba($color, $opacity = false) {
	$default = 'rgb(0,0,0)';
	
	// Return default if no color provided
	if (empty ( $color ))
		return $default;
		
		// Sanitize $color if "#" is provided
	if ($color [0] == '#') {
		$color = substr ( $color, 1 );
	}
	
	// Check if color has 6 or 3 characters and get values
	if (strlen ( $color ) == 6) {
		$hex = array (
				$color [0] . $color [1],
				$color [2] . $color [3],
				$color [4] . $color [5] 
		);
	} elseif (strlen ( $color ) == 3) {
		$hex = array (
				$color [0] . $color [0],
				$color [1] . $color [1],
				$color [2] . $color [2] 
		);
	} else {
		return $default;
	}
	
	// Convert hexadec to rgb
	$rgb = array_map ( 'hexdec', $hex );
	
	// Check if opacity is set(rgba or rgb)
	if ($opacity) {
		if (abs ( $opacity ) > 1)
			$opacity = 1.0;
		$output = 'rgba(' . implode ( ",", $rgb ) . ',' . $opacity . ')';
	} else {
		$output = 'rgb(' . implode ( ",", $rgb ) . ')';
	}
	
	// Return rgb(a) color string
	return $output;
}
// ------------------------------------------------------
function fromRGB($R, $G, $B) {
	$R = dechex ( $R );
	if (strlen ( $R ) < 2)
		$R = '0' . $R;
	
	$G = dechex ( $G );
	if (strlen ( $G ) < 2)
		$G = '0' . $G;
	
	$B = dechex ( $B );
	if (strlen ( $B ) < 2)
		$B = '0' . $B;
	
	return '#' . $R . $G . $B;
}
// ---------------------------End functions-------------------------------------

$img = isset($_REQUEST['image']) ? $_REQUEST['image'] : '' ;
$img = "../../img/Motif/". trim($img) . ".png";
$uid = isset($_REQUEST['user']) ? $_REQUEST['user'] : '';
$title= isset($_REQUEST['title']) ? $_REQUEST['title'] : '';
$designer= isset($_REQUEST['designer']) ? $_REQUEST['designer'] : '';

if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
	$ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
	$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
	$ip = $_SERVER['REMOTE_ADDR'];
}
error_log($ip." - ".date("Y/m/d h:i:sa")." - remotesave.php downloaded chart for: ".$img." title: ".$title
." - : id_customer=". ($uid/3).
"\n", 3, _PDF_DOWNLOAD_LOG_FILE_);

// Logging logic
        // check for bots, if it is a bot we do not logg
        //
    $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? strtolower($_SERVER['HTTP_USER_AGENT']) : '';
    $ip = Tools::getRemoteAddr();

    $is_bot = false;

    // Check for bot user agents
    $bot_keywords = [
        'bot', 'crawl', 'slurp', 'spider', 'mediapartners', 'google', 'bing', 'yandex',
        'baidu', 'facebookexternalhit', 'python-requests', 'wget', 'curl'
    ];

    $i = 0;
    $count = count($bot_keywords);

    while ($i < $count) {
        if (strpos($user_agent, $bot_keywords[$i]) !== false) {
            $is_bot = true;
            break;
        }
        $i++;
    }

    // Continue only if it's not a bot
    if (!$is_bot) {
      $ip = Tools::getRemoteAddr();

      $referrer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'direct';
      $customer_id = isset($uid) ? $uid/3 : 'guest';
      $customer_name = "n/a";
	     // $this->context->customer->firstname . ' ' . $this->context->customer->lastname;

      $product_id = $img."-".$title; 
	      //Tools::getValue('id_product', 'n/a');

      $page = 'pdfdownload';

      $log_line = sprintf("%s, %s, %s, %s, %s, %s, %s \n",
        $ip,
        date("Y/m/d h:i:sa"),
        $customer_id,
        $customer_name,
        $product_id,
        $page,
        $referrer
      );

      error_log($log_line, 3, _MOTIF_LOG_FILE_);
    }
                                                                                                                                                     

//logging logic ends
																			     

/*if (!$uid) {
	$value = "<div> Please logg in to get access to the chart. It is free. Just do it on the right top side of the page.</div>";
	$html .= "$value";
} else {
* Just because crawlers can't crawl the charts if this check is on.
*/
	$text_first = '<br/>Knitting motif, ' . $title . ' created by '.$designer.' <br/> &nbsp;<br/>';
	
	$text_after = <<<EOF
<br/><br/>
The chart was created on
<a href="http://localhost/motif"> https://motif.knittedforyou.com.</a> The ultimate website to use for knitting with more colors.
EOF;
	
	$resource = imagecreatefrompng ( $img );
	$width = imagesx ( $resource );
	$height = imagesy ( $resource );
	$widex = 0;
	if ($width > 50) {
		$widex = 1;
	}
	
	//pdf pagewith seems to 640 (inside original margins)
	$pagewidth_default = 620;
	$boxwidth_max = 25;
	/*if ($width <= 25) { $boxwidth = 25; }
	elseif ($width <= 64) { $boxwidth = 10; }
	else {$boxwidth = 5; }*/
    $boxwidth = intdiv($pagewidth_default, $width);
    if ($boxwidth > $boxwidth_max) $boxwidth = $boxwidth_max;
    
	//pdf pageheight seems to be 720 (inside original margins)
	$pageheight_default = 720;
	/*if ($height <= 33) { $boxheight = 25; }
	elseif ($height <= 90) { $boxheight = 15; }
	else $boxheight = 5;*/
	$boxheight = intdiv($pageheight_default, $height);
	
	if ($boxheight > $boxwidth) $boxheight = $boxwidth;
	else $boxwidth = $boxheight;
	
	//$boxheight = 15;
    $fontsize = 6;
    $fontsize_default = 12;
    if ($boxheight >= 6 && $boxheight <= 10) $fontsize = 6;
    elseif ($boxheight > 10 && $boxheight <= 20) $fontsize = 10;
    elseif ($boxheight > 20) $fontsize = 12;
    elseif ($boxheight <= 5) $fontsize = 3;
    
   $border_color = array('#000', '#ccc', '#f00');
  
    //generating the table content
    $tbl = '<table style="border-collapse: collapse;" cellspacing="0" 	cellpadding="0">';
    
    
    for($y = 0; $y < $height; $y ++) {
		$tbl .= '<tr>'; // begin of each line ...1
		             // $mpdf->writehtml('<tr>');
		for($x = 0; $x < $width; $x ++) { // pixel color at (y, x)
			$rgb = imagecolorat ( $resource, $x, $y );
			
			// -----
			$r = ($rgb >> 16) & 0xFF;
			$g = ($rgb >> 8) & 0xFF;
			$b = $rgb & 0xFF;
			// -----
			
			// $color =imagecolorsforindex($resource, $rgb);
			$r = imagecolorsforindex ( $resource, $rgb )["red"];
			$g = imagecolorsforindex ( $resource, $rgb )["green"];
			$b = imagecolorsforindex ( $resource, $rgb )["blue"];
			$a = imagecolorsforindex ( $resource, $rgb )["alpha"];
			$color = fromRGB ( $r, $g, $b );
			$tbl .= '<td bgcolor="' . $color . '"></td>';
			//error_log('rgb: '.$r.'-'.$g.'-'.$b.' color: '.$color);
			// $tbl .= '<td style="border:1px solid #f00;" width="25" height="25" bgcolor="' . $color . '"></td>'; //background: rgba( 156, 25, 26, 0.8);
			
			//check for border_color
			if ($r < 50 && $g < 50 && $b < 50 ) $border_color = array_diff($border_color, array('#000')); //if any of the motifs color is to dark we should use some other color to grid.
			if ($r > 230 && $g < 50 && $b < 50 ) $border_color = array_diff($border_color, array('#f00')); //if any of the motifs color is too red we should use some other color to grid.
			if ($r < 221 && $g < 221 && $b < 221 &&
			    $r > 187 && $g > 187 && $b > 187) $border_color = array_diff($border_color, array('#ccc')); //if any of the motifs color is too gray we should use some other color to grid.
			
		}
		
		$line = $height - $y;
		if ($widex == 0) {
		    $tbl .= '<td style="border: 0px solid #fff;width:30px;"> ' . $line . '</td>';
		}
		if ($widex == 1) {
		    if ($line % 5 == 0) {
		      $tbl .= '<td  style="border: 0px solid #fff;width:20px;" rowspan=5> ' . $line . '</td>';
		    }
		}
		
		$tbl .= '</tr>';
		
		//each row shall be inserted in pdf to avoid memory overload. 
		// output the HTML content
		//$pdf->writeHTML($tbl, true, false, true, false, '');
		//$tbl = '';
		
	} // end of each line......1
	
	$tbl .= '<tr>';
	if ($widex == 0) {
		for($x = 0; $x < $width + 1; $x ++) {
			$tbl .= '<td style="border: 0px solid #fff;">' . ($width - $x) . '</td>'; // $mpdf->writehtml('<<td width="25" height="25" >' . $x . '</td>>');
		}
	}
	if ($widex == 1){
	   $start_numbering = $width % 5; //this is the stitches above the last 5 dividable.
	   if ($start_numbering > 0)
	       $tbl .= '<th style="border: 0px solid #fff;" colspan="'.$start_numbering.'"></th>';
	   
	   for($x = $width - $start_numbering; $x > 0; $x -= 5) {
		    	    $tbl .= '<th style="border: 0px solid #fff;" colspan="5">' . $x . '</th>';				    
		}
	}
	$tbl .= '</tr>';
	
	$tbl .= "</table>";
/*}*/
	
	if (count($border_color) < 1) $border_color = array('#ccc');
	
	$style = '
        <style>
            td {
                border:1px solid '.array_shift($border_color).';
                opacity:1;
                width:'.$boxwidth.';
                height:'.$boxheight.';
                text-align: center;
                vertical-align: middle;
            }; </style>';
	
	
//$html = '     <table style="border-collapse: collapse;" cellspacing="0" cellpadding="0">        <style>                        td {                border:1px solid #111;                opacity:1;                width:13.333333333333;                height:13.333333333333;                text-align: center;                 vertical-align: middle;            };                   </style><tr><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#000000"></td><td bgcolor="#000000"></td><td bgcolor="#000000"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td bgcolor="#ffffff"></td><td style="border: 0px solid #fff;"> 11</td></tr>';
//$html .= '<tr><td style="border: 0px solid #fff;">48</td><td style="border: 0px solid #fff;">47</td><td style="border: 0px solid #fff;">46</td><td style="border: 0px solid #fff;">45</td><td style="border: 0px solid #fff;">44</td><td style="border: 0px solid #fff;">43</td><td style="border: 0px solid #fff;">42</td><td style="border: 0px solid #fff;">41</td><td style="border: 0px solid #fff;">40</td><td style="border: 0px solid #fff;">39</td><td style="border: 0px solid #fff;">38</td><td style="border: 0px solid #fff;">37</td><td style="border: 0px solid #fff;">36</td><td style="border: 0px solid #fff;">35</td><td style="border: 0px solid #fff;">34</td><td style="border: 0px solid #fff;">33</td><td style="border: 0px solid #fff;">32</td><td style="border: 0px solid #fff;">31</td><td style="border: 0px solid #fff;">30</td><td style="border: 0px solid #fff;">29</td><td style="border: 0px solid #fff;">28</td><td style="border: 0px solid #fff;">27</td><td style="border: 0px solid #fff;">26</td><td style="border: 0px solid #fff;">25</td><td style="border: 0px solid #fff;">24</td><td style="border: 0px solid #fff;">23</td><td style="border: 0px solid #fff;">22</td><td style="border: 0px solid #fff;">21</td><td style="border: 0px solid #fff;">20</td><td style="border: 0px solid #fff;">19</td><td style="border: 0px solid #fff;">18</td><td style="border: 0px solid #fff;">17</td><td style="border: 0px solid #fff;">16</td><td style="border: 0px solid #fff;">15</td><td style="border: 0px solid #fff;">14</td><td style="border: 0px solid #fff;">13</td><td style="border: 0px solid #fff;">12</td><td style="border: 0px solid #fff;">11</td><td style="border: 0px solid #fff;">10</td><td style="border: 0px solid #fff;">9</td><td style="border: 0px solid #fff;">8</td><td style="border: 0px solid #fff;">7</td><td style="border: 0px solid #fff;">6</td><td style="border: 0px solid #fff;">5</td><td style="border: 0px solid #fff;">4</td><td style="border: 0px solid #fff;">3</td><td style="border: 0px solid #fff;">2</td><td style="border: 0px solid #fff;">1</td><td style="border: 0px solid #fff;">0</td></tr></table>'; 
//generating pdf
	//error_log($html);
	

// create new PDF document
//starting pdf document
$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->SetTitle('Knitting motif chart');
$pdf->SetSubject('Knitting motif chart');
$pdf->SetKeywords('Knitting motif, motif knitting, knitting chart');

// set default header data
$pdf->SetHeaderData('../../../img/KfYlogo.jpg', 100, '', '');

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
$pdf->SetFooterData('', 0, '', 'haho');

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
    require_once(dirname(__FILE__).'/lang/eng.php');
    $pdf->setLanguageArray($l);
}




// ---------------------------------------------------------

// set font
$pdf->SetFont('helvetica', '', $fontsize_default);

// add a page
$pdf->AddPage();
$pdf->writeHTML($text_first, true, false, true, false, '');

$pdf->SetFont('helvetica', '', $fontsize);


// output the HTML content
$pdf->writeHTML($style.$tbl, true, false, true, false, '');

$pdf->SetFont('helvetica', '', $fontsize_default);
$pdf->writeHTML($text_after, true, false, true, false, '');


// reset pointer to the last page
$pdf->lastPage();

// ---------------------------------------------------------

//Close and output PDF document
$pdf->Output('example_021.pdf', 'I');

//echo $html;
//============================================================+
// END OF FILE


function intdiv($a, $b){
    return ($a - $a % $b) / $b;
}
?>

?>
