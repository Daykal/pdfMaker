to install the script ,
1-copy the files in your server.
2-edit remotesave.php;
go to line N� 5 and update this :
$value = 'https://kaleeeed.000webhostapp.com/index.php?image='.$img.'&title='.$title; // change this to your url kaleeeed.000webhostapp.com.

you can now use the script like this

https://Your URL/remotesave.php?image=imageadressHere&title=titleHere.