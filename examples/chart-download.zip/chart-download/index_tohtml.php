<?php  
include_once('../../config/config.inc.php');
include_once('../../config/defines.inc.php');
include_once('../../init.php');

?>

<html>
<head>
	<title>Knitting motif chart, Valentin hearts</title>
	<link rel="shortcut icon" type="image/x-icon" href="../../img/favicon.ico">
</head>	
<table style="border-collapse: collapse;" cellspacing="0"
	cellpadding="0">
</html>
	

<?php
// include('save.php');
// ---------------------------functions----------------------------------------------
function hex2rgba($color, $opacity = false) {
	$default = 'rgb(0,0,0)';
	
	// Return default if no color provided
	if (empty ( $color ))
		return $default;
		
		// Sanitize $color if "#" is provided
	if ($color [0] == '#') {
		$color = substr ( $color, 1 );
	}
	
	// Check if color has 6 or 3 characters and get values
	if (strlen ( $color ) == 6) {
		$hex = array (
				$color [0] . $color [1],
				$color [2] . $color [3],
				$color [4] . $color [5] 
		);
	} elseif (strlen ( $color ) == 3) {
		$hex = array (
				$color [0] . $color [0],
				$color [1] . $color [1],
				$color [2] . $color [2] 
		);
	} else {
		return $default;
	}
	
	// Convert hexadec to rgb
	$rgb = array_map ( 'hexdec', $hex );
	
	// Check if opacity is set(rgba or rgb)
	if ($opacity) {
		if (abs ( $opacity ) > 1)
			$opacity = 1.0;
		$output = 'rgba(' . implode ( ",", $rgb ) . ',' . $opacity . ')';
	} else {
		$output = 'rgb(' . implode ( ",", $rgb ) . ')';
	}
	
	// Return rgb(a) color string
	return $output;
}
// ------------------------------------------------------
function fromRGB($R, $G, $B) {
	$R = dechex ( $R );
	if (strlen ( $R ) < 2)
		$R = '0' . $R;
	
	$G = dechex ( $G );
	if (strlen ( $G ) < 2)
		$G = '0' . $G;
	
	$B = dechex ( $B );
	if (strlen ( $B ) < 2)
		$B = '0' . $B;
	
	return '#' . $R . $G . $B;
}
// ---------------------------End functions-------------------------------------

$img = isset($_REQUEST['image']) ? $_REQUEST['image'] : '' ;
$img = "../../img/Motif/". trim($img) . ".png";
$uid = isset($_REQUEST['user']) ? $_REQUEST['user'] : '';
$title= isset($_REQUEST['title']) ? $_REQUEST['title'] : '';
$designer= isset($_REQUEST['designer']) ? $_REQUEST['designer'] : '';

if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
	$ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
	$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
	$ip = $_SERVER['REMOTE_ADDR'];
}
error_log($ip." - ".date("Y/m/d h:i:sa")." - remotesave.php downloaded chart for: ".$img." title: ".$title
." - : id_customer=". ($uid/3).
"\n", 3, _PDF_DOWNLOAD_LOG_FILE_);


/*if (!$uid) {
	$value = "<div> Please logg in to get access to the chart. It is free. Just do it on the right top side of the page.</div>";
	echo "$value";
} else {
* Just because crawlers can't crawl the charts if this check is on.
*/
	echo '<br/>Knitting motif, ' . $title . ' created by '.$designer.' <br/> &nbsp;<br/>';
	$resource = imagecreatefrompng ( $img );
	$width = imagesx ( $resource );
	$height = imagesy ( $resource );
	$widex = 0;
	if ($width > 50) {
		$widex = 1;
	}
	
	for($y = 0; $y < $height; $y ++) {
		echo '<tr>'; // begin of each line ...1
		             // $mpdf->writehtml('<tr>');
		$line = $height - $y;
		if ($widex == 0) {
			echo '<td width="25" height="25">' . $line . '</td>';
		}
		if ($widex == 1) {
			if ($line % 5 != 0) {
				$line = '';
			}
			echo '<td width="25" height="25">' . $line . '</td>';
		}
		for($x = 0; $x < $width; $x ++) { // pixel color at (y, x)
			$rgb = imagecolorat ( $resource, $x, $y );
			
			// -----
			$r = ($rgb >> 16) & 0xFF;
			$g = ($rgb >> 8) & 0xFF;
			$b = $rgb & 0xFF;
			// -----
			
			// $color =imagecolorsforindex($resource, $rgb);
			$r = imagecolorsforindex ( $resource, $rgb )["red"];
			$g = imagecolorsforindex ( $resource, $rgb )["green"];
			$b = imagecolorsforindex ( $resource, $rgb )["blue"];
			$a = imagecolorsforindex ( $resource, $rgb )["alpha"];
			$color = fromRGB ( $r, $g, $b );
			echo '<td style="border:1px solid #f00; opacity:1;" width="25" height="25" bgcolor="' . $color . '"></td>';
			// echo '<td style="border:1px solid #f00;" width="25" height="25" bgcolor="' . $color . '"></td>'; //background: rgba( 156, 25, 26, 0.8);
		}
		
		echo '</tr>';
	} // end of each line......1
	
	echo '<tr>';
	if ($widex == 0) {
		for($x = 0; $x < $width + 1; $x ++) {
			echo '<td width="25" height="25" >' . $x . '</td>'; // $mpdf->writehtml('<<td width="25" height="25" >' . $x . '</td>>');
		}
	}
	if ($widex == 1)
		for($x = 0; $x < $width + 1; $x ++) {
			$xt = $x;
			if ($x % 5 != 0)
				$xt = '';
			echo '<td width="25" height="25" >' . $xt . '</td>'; // $mpdf->writehtml('<<td width="25" height="25" >' . $x . '</td>>');
		}
	echo '</tr>';
	
	echo "</table>";
/*}*/
?>
<br/><br/>
The chart was created on
<a href="http://motif.knittedforyou.com"> http://motif.knittedforyou.com.</a> The ultimate website to use for knitting with more colors. <br/><br/><br/>
<a href="http://motif.knittedforyou.com">
<img class="logo img-responsive" alt="Stickningsmotiv" src="http://motif.knittedforyou.com/img/stickningsmotiv-logo-1462266010.png" width="" height="30">
</a>
